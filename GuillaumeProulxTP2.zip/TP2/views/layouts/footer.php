    </main>
        <footer>
            <span>2024 All rights reserved</span>
        </footer>
    </body>
</html>
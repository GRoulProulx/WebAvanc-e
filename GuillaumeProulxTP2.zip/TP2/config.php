<?php
define('BASE', '/webAvancee23620/TP2');
define('ASSET', '/webAvancee23620/TP2/public/');

?>